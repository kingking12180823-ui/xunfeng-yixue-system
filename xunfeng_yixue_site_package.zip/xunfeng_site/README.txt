巽風易學決策系統｜靜態網站上線包

檔案說明：
- index.html：可直接部署到 Vercel、Netlify、Cloudflare Pages、GitHub Pages 的靜態網站首頁。

部署方式：
1. 將 index.html 上傳到任何靜態網站主機。
2. 首頁檔名保持 index.html。
3. 部署完成後，主機平台會產生公開網址。

注意：
目前版本為前端原型，會員、報告與預約資料暫存於瀏覽器 localStorage。
正式商業上線需再接後端資料庫、登入權限、金流與通知系統。
